# Grok Build plan-mode 提示詞：mykatago 加入 KaTrain 式復盤功能

> 用法：在 mykatago 根目錄執行 `grok`，切換到 plan mode，把下方「提示詞」整段貼上。
> 先把同一個 zip 裡的 6 份參考文件放進 `docs/programming/`。

---

## 提示詞

你在 mykatago 的 repo 裡（Kotlin Multiplatform + Compose Multiplatform）。目標是參考 KaTrain（https://github.com/sanderland/katrain），把它的**復盤**功能做進來，引擎一樣用 KataGo。**只做 macOS 桌面版。**現在是 plan mode，請只產出計畫，不要修改任何檔案。

### 先讀
1. `docs/programming/` 裡的這幾份文件：
   - `katrain_feature_inventory_ref.md`
   - `katago_analysis_engine_protocol_ref.md`
   - `sgf_and_game_tree_ref.md`
   - `review_ui_layout_ref.md`
   - `analysis_options_ref.md`
   - `mykatago_migration_plan_ref.md`
   - 現有的 `How-To-Change_Project_Name.md`、`How-To-Change_Version_number.md`
2. 檢查 repo 的實際狀態，確認文件寫的現況是否正確，有出入就列出來：
   - `gradle/libs.versions.toml`、兩個 `build.gradle.kts`、`gradle.properties`、`configure.sh`
   - `composeApp/src/**` 底下所有 .kt 檔，特別是 `App.kt`、`AppVersion.kt`、`HomeScreen.kt`、`Main.kt`、`MyTopMenuBar.kt`

### 目標（希望一次完成）
做出一個像 KaTrain Analysis 模式的復盤視窗，功能如下：
- 載入 SGF（⌘O）。
- 中央是 19 路棋盤：座標 A–T（跳過 I）與 1–19、棋子、最後一手標記、候選手彩色圓（依點損分級，顯示「點損／visits」）、評估點、下一手框。
- 頂列：5 個開關（下一手、顯示選點、最佳選點、直覺選點、形勢判斷），加上「分析選項」下拉選單（項目與快捷鍵照 `analysis_options_ref.md` §1）。
- 底部導覽列：Pass、上一個失誤、|◀、◀◀(10)、◀、黑白輪次、▶、▶▶(10)、▶|、下一個失誤、引擎狀態燈、移動滑桿、跳到第 N 手；鍵盤快捷鍵。
- 右側面板：棋手卡、勝率、預估目差、本手點損、候選手表、勝率與目差圖（可以點擊跳轉）、詳細資訊與註記。
- 分析功能：持續分析目前局面（空白鍵）、深度分析（a）、重設分析（⌃H）、整局分析與 F2 深度全盤分析對話框。
- 「分析設定」對話框：max/fast visits、時間上限、wide root noise、分析執行緒數。
- 「引擎設定」：katago 執行檔、模型、cfg 的路徑，支援 Homebrew 路徑自動偵測與測試引擎。
- 設定要能持久化。

如果無法一次完成，就照 `mykatago_migration_plan_ref.md` §3 的 Phase 0→4 順序規劃。每個 Phase 都要能獨立合併，build 不能壞掉，也要符合文件裡的驗收條件。P1 和 P2 只需要列出後續步驟。

### 限制
- 只做 macOS Desktop（`jvm("desktop")`）。引擎、Process、檔案 IO 一律放在 `desktopMain`。`commonMain` 只放純 Kotlin 的模型、規則、SGF、分析邏輯和 UI。
- **不要刪除 wasmJs target 或相關程式碼。**`configure.sh` 依賴 `wasmJsMain`。如果你認為應該移除，先在計畫中提出理由，並詢問 Neo。wasm 端只要能編譯並顯示「不支援」即可。
- 不能讓 build 失敗：每個 Phase 結束時 `./gradlew :composeApp:run` 和測試都要通過。
- 只用 KataGo **Analysis Engine（JSON lines）**，不要用 GTP。每個 query 都要在 overrideSettings 帶 `reportAnalysisWinratesAs=BLACK`。要處理 terminate 和 generation，避免舊結果寫到新棋譜上。
- UI 文字一律用 **zh-TW**，用語參考 KaTrain 的 `tw` 翻譯（文件裡已經整理好）。
- 保留 About 對話框、`AppVersion` 和 macOS About handler。版號用 `./configure.sh version` 修改，請在計畫中建議版號。
- 不要複製 KaTrain 的圖片、音效或字型。用 Canvas 繪製或 Material Icons。在 NOTICE 註明參考 KaTrain（MIT）。
- 新增依賴（kotlinx-serialization、coroutines 等）時，要寫出版本，並說明跟 Kotlin 2.3.0 / Compose 1.10.0 的相容性。
- 任何你沒有在 repo 或文件中確認過的 API、版本、路徑（例如 Compose `MenuBar` 的簽名、Homebrew 路徑、KataGo 參數），都要標記 **【未驗證】**，並寫出怎麼驗證。

### 計畫要包含
1. 現況摘要，以及文件與 repo 不一致的地方。
2. 架構圖或分層說明，包括 state 怎麼流動、引擎 coroutine 與 query 路由的設計。
3. **檔案層級的清單**：新增、修改、不動的檔案，每個檔案寫出路徑、職責和主要的類別或函式。
4. 每個 Phase 的步驟、驗收條件、測試清單（commonTest）。
5. Gradle 的修改內容（寫出 diff 的大意）。
6. 風險與開放問題，需要 Neo 決定的事項列在最後。
